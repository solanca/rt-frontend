import React from 'react';

function NotesComponent() {
  return <div>Notes Content</div>;
}

export default NotesComponent;
