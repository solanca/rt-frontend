import React from 'react';

function HotlistComponent() {
  return <div>Hotlist Content</div>;
}

export default HotlistComponent;
