import React from 'react';

function ChatsComponent() {
  return <div>Chats Content</div>;
}

export default ChatsComponent;
