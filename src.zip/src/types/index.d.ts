export type PanelType =  "watchlist"|"alerts"|"hotlist"|"calendar"|"notes"|"chats"|"ideasStream"|"liveStreams"|"calculator";
