export const WS_URL = import.meta.env.VITE_WS_SERVER_URL;
export const HTTP_URL = import.meta.env.VITE_HTTP_SERVER_URL;