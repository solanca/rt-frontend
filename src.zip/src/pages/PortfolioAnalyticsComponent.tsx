import DefaultTopBar from "./topbars/DefaultTopBar";

function PortfolioAnalyticsComponent() {
  return (
    <div className="flex-item">
      <DefaultTopBar />

      <div>This is the PortfolioAnalyticsComponent</div>
    </div>
  );
}

export default PortfolioAnalyticsComponent;
