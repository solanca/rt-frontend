/// <reference types="vite/client" />
declare module 'react-treebeard';
declare module 'recharts';
