import React from 'react';

function AlertsComponent() {
  return <div>Alerts aewea nContent</div>;
}

export default AlertsComponent;
