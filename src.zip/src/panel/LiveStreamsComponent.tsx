import React from 'react';

function LiveStreamsComponent() {
  return <div>Live Streams Content</div>;
}

export default LiveStreamsComponent;
