import React, { useEffect } from 'react';

function CalculatorComponent() {

 return (
  <div id="profit-calculator-767602">calc</div>  
 );
}

export default CalculatorComponent;